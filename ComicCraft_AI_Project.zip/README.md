# ComicCraft - AI Comic Story Creator

A FastAPI web application based on the supplied project specification. It collects a story prompt, character, setting, tone and art style; generates a 5-panel outline with Gemini Flash, expands it with Gemini Pro, creates panel illustrations with Stable Diffusion, renders a preview, and exports a PDF.

## Project structure
- app/main.py - FastAPI application
- app/routes.py - main routes and workflow
- app/gemini_flash.py - 5-panel outline generation
- app/gemini_pro.py - narration/dialogue generation
- app/image_generator.py - Stable Diffusion image generation
- app/layout_builder.py - panel layout assembly
- app/exporters.py - PDF export
- app/schemas.py - Pydantic request model
- templates/ - Jinja2 pages
- static/panels/ - generated images
- static/exports/ - generated PDFs

## Setup
1. Create and activate a virtual environment.
2. Run `pip install -r requirements.txt`.
3. Copy `.env.example` to `.env`.
4. Add your Gemini API key.
5. For local Stable Diffusion, ensure the machine has suitable GPU/CPU resources.
6. Run: `uvicorn app.main:app --reload`
7. Open http://127.0.0.1:8000 and API docs at /docs.

## Important
The supplied specification names Gemini 1.5 Flash/Pro and Stable Diffusion v1.5. Model availability can change; update the model names in `.env` if required by your API account.
