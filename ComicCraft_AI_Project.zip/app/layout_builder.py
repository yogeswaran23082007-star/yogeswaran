def build_comic_layout(outline, story, image_paths):
    story_by_panel = {item["panel_number"]: item for item in story}
    layout = []
    for item, image_path in zip(outline, image_paths):
        panel_no = item["panel_number"]
        script = story_by_panel.get(panel_no, {})
        layout.append({
            "panel_number": panel_no,
            "title": item.get("title", f"Panel {panel_no}"),
            "image": image_path,
            "scene_description": item.get("scene_description", ""),
            "image_prompt": item.get("image_prompt", ""),
            "caption": script.get("caption", ""),
            "narration": script.get("narration", ""),
            "dialogue": script.get("dialogue", "")
        })
    return layout
