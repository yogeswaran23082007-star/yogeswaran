from pathlib import Path
import re
from app.config import SD_MODEL

_PIPELINE = None

def _safe_name(value):
    return re.sub(r"[^a-zA-Z0-9_-]+", "_", value)[:60].strip("_") or "panel"

def _get_pipeline():
    global _PIPELINE
    if _PIPELINE is None:
        from diffusers import StableDiffusionPipeline
        import torch
        _PIPELINE = StableDiffusionPipeline.from_pretrained(
            SD_MODEL,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
        )
        if torch.cuda.is_available():
            _PIPELINE = _PIPELINE.to("cuda")
    return _PIPELINE

def generate_image(image_prompt, panel_number):
    output_dir = Path("static/panels")
    output_dir.mkdir(parents=True, exist_ok=True)
    filename = f"panel_{panel_number}_{_safe_name(image_prompt)}.png"
    path = output_dir / filename
    pipe = _get_pipeline()
    image = pipe(image_prompt, num_inference_steps=25).images[0]
    image.save(path)
    return f"/static/panels/{filename}"
