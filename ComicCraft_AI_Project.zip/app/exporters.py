from pathlib import Path
from datetime import datetime
from fpdf import FPDF
import requests

def save_pdf(layout):
    out_dir = Path("static/exports")
    out_dir.mkdir(parents=True, exist_ok=True)
    filename = f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    output = out_dir / filename

    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)

    for panel in layout:
        pdf.add_page()
        pdf.set_font("Arial", "B", 18)
        pdf.multi_cell(0, 10, str(panel["title"]))
        image_path = panel["image"]
        if image_path.startswith("/static/"):
            local_path = Path(image_path.lstrip("/"))
        else:
            local_path = Path(image_path)
        if local_path.exists():
            pdf.image(str(local_path), x=15, y=35, w=180)
            pdf.set_y(145)
        pdf.set_font("Arial", "", 11)
        for label, key in [("Scene", "scene_description"), ("Caption", "caption"),
                           ("Narration", "narration"), ("Dialogue", "dialogue")]:
            text = str(panel.get(key, ""))
            if text:
                pdf.set_font("Arial", "B", 11)
                pdf.cell(0, 7, label)
                pdf.ln()
                pdf.set_font("Arial", "", 10)
                pdf.multi_cell(0, 6, text)
                pdf.ln(2)

    pdf.output(str(output))
    return f"/static/exports/{filename}"
