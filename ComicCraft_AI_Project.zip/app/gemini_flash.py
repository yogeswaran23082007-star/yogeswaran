import json
import re
import google.generativeai as genai
from app.config import GEMINI_API_KEY, GEMINI_FLASH_MODEL

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

def _extract_json(text: str):
    text = text.strip()
    text = re.sub(r"^```json\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    match = re.search(r"\[.*\]", text, flags=re.S)
    if match:
        text = match.group(0)
    return json.loads(text)

def generate_outline(story_prompt, character_name, setting, tone, art_style):
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    model = genai.GenerativeModel(GEMINI_FLASH_MODEL)
    prompt = f"""
Create a structured 5-panel comic outline.
Story prompt: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Return ONLY valid JSON as an array of 5 objects. Each object must contain:
panel_number, title, scene_description, image_prompt.
"""
    response = model.generate_content(prompt)
    return _extract_json(response.text)
