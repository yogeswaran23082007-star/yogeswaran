import google.generativeai as genai
from app.config import GEMINI_API_KEY, GEMINI_PRO_MODEL

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

def generate_story(outline):
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is not configured.")
    model = genai.GenerativeModel(GEMINI_PRO_MODEL)
    prompt = f"""
Expand the following 5-panel comic outline into a complete comic script.
For every panel provide: caption, narration, and dialogue.
Keep characters and setting consistent. Tone and visual intent should match the outline.
Return ONLY valid JSON as an array with the same 5 panels.
Outline:
{outline}
"""
    response = model.generate_content(prompt)
    text = response.text.strip().replace("```json", "").replace("```", "")
    import json
    return json.loads(text)
